<!DOCTYPE html>
<html lang="en">

<head>
    <!--
    *
    * Created By Md Ibrahim Kholil
    * Copyright AwesomeCoder
    *
    *                                                              _
    *                                                             | |
    *    __ ___      _____  ___  ___  _ __ ___   ___  ___ ___   __| | ___ _ __
    *   / _` \ \ /\ / / _ \/ __|/ _ \| '_ ` _ \ / _ \/ __/ _ \ / _` |/ _ \ '__|
    *  | (_| |\ V  V /  __/\__ \ (_) | | | | | |  __/ (_| (_) | (_| |  __/ |
    *   \__,_| \_/\_/ \___||___/\___/|_| |_| |_|\___|\___\___/ \__,_|\___|_|
    *
    *
    *-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AwesomeCoder | Mohammad Ibrahim</title>
    <meta name="description" content="I will make your visions become reality, and I love what I do. Since beginning my journey as a web developer nearly 4 years ago, I've done remote work for agencies, consulted for startups.">
    <meta name="robots" content="index, follow">
    <meta name='mobile-web-app-capable' content='yes'>
    <meta name='apple-mobile-web-app-capable' content='yes'>
    <meta name="twitter:title" content="AwesomeCoder | Mohammad Ibrahim">
    <meta name="twitter:description" content="I will make your visions become reality, and I love what I do. Since beginning my journey as a web developer nearly 4 years ago, I've done remote work for agencies, consulted for startups.">
    <meta name="twitter:image" content="https://awesomecoder.dev/img/profile.jpg">
    <meta name="twitter:site" content="@mkholilulla">
    <meta name="twitter:creator" content="@mkholilulla">

    <meta property="og:type" content="article" />
    <meta property="og:title" content="AwesomeCoder | Mohammad Ibrahim" />
    <meta property="og:description" content="I will make your visions become reality, and I love what I do. Since beginning my journey as a web developer nearly 4 years ago, I've done remote work for agencies, consulted for startups, and collaborated with talented people to create digital products for both business and customer use. I'm quietly confident, naturally curious, and perpetually working on improving my chops one problem at a time." />
    <meta property="og:image" content="https://awesomecoder.dev/img/profile.jpg" />
    <meta property="og:url" content="https://awesomecoder.dev/" />
    <meta property="og:site_name" content="AwesomeCoder | Mohammad Ibrahim" />
    <meta name="theme-color" content="#2C2F32">
    <meta http-equiv="Content-language" content="en">

    <link rel="apple-touch-icon" sizes="180x180" href="https://awesomecoder.dev/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://awesomecoder.dev/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://awesomecoder.dev/favicon-16x16.png">
    <link rel="manifest" href="https://awesomecoder.dev/site.webmanifest">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://awesomecoder.dev/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://awesomecoder.dev/css/style.css">

    <!-- jquery JS -->
    <script src="https://awesomecoder.dev/js/jquery.min.js"></script>
    <!-- Swiper JS -->
    <script src="https://awesomecoder.dev/js/swiper-bundle.min.js"></script>
    <!-- Typed JS -->
    <script src="https://awesomecoder.dev/js/typed.js"></script>
    <!-- scrollreveal JS -->
    <script src="https://awesomecoder.dev/js/scrollreveal.js"></script>
    <meta name="google-site-verification" content="vnKjQ-hJClFlOtcWjBElR8oGqi8eadcXHRbpDP7IQUg" />
</head>

<body>
    <!-- sccroll top  -->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bxs-up-arrow scrolltop__icon'></i>
    </a>

    <!-- Header -->
    <header>
        <nav>
            <a href="https://awesomecoder.dev/#home">
                <div class="nav__logo">Awesome<span>Coder</span> </div>
            </a>
            <div class="nav__items">
                <ul class="nav__list">
                    <li class="nav__item"><a href="https://awesomecoder.dev/#home" class=" nav__link active">Home</a></li>
                    <li class="nav__item"><a href="https://awesomecoder.dev/#skills" class=" nav__link">Skills</a></li>
                    <li class="nav__item"><a href="https://awesomecoder.dev/#testmonials" class=" nav__link">Testmonials</a></li>
                    <li class="nav__item"><a href="https://awesomecoder.dev/#about" class=" nav__link">About</a></li>
                    <li class="nav__item"><a href="https://awesomecoder.dev/#contact" class=" nav__link">Contact</a></li>
                </ul>
            </div>
            <div class="mobile__menu">
                <i class='bx bx-menu-alt-left'></i>
            </div>
        </nav>

    </header>

    <!-- header section -->
    <section class="home" id="home">
        <div class="header">
            <div class="header__container">
                <div class="header__content">
                    <h1 class="header__title">Talk is cheap.</h1>
                    <h1 class="header__subtitle">Show me the code</h1>
                    <p>I will make your visions become reality, and I love what I do.</p>
                    <a class="header__button" target="_blank" href="https://api.whatsapp.com/send?phone=8801720115642">Let's Talk</a>

                </div>

                <div class="header__exp">
                    <svg class="header__svg" viewBox="0 0 602 602" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g opacity="0.15">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M201.337 87.437C193.474 79.5738 180.725 79.5738 172.862 87.437L87.437 172.862C79.5739 180.725 79.5739 193.474 87.437 201.337L400.663 514.563C408.526 522.426 421.275 522.426 429.138 514.563L514.563 429.138C522.426 421.275 522.426 408.526 514.563 400.663L201.337 87.437ZM30.4869 115.912C-8.82897 155.228 -8.82897 218.972 30.4869 258.287L343.713 571.513C383.028 610.829 446.772 610.829 486.088 571.513L571.513 486.088C610.829 446.772 610.829 383.028 571.513 343.713L258.287 30.4869C218.972 -8.82896 155.228 -8.82896 115.912 30.4869L30.4869 115.912Z" stroke="url(#paint0_radial)" id="path_0"></path>
                            <path d="M514.563 201.337C522.426 193.474 522.426 180.725 514.563 172.862L429.138 87.437C421.275 79.5738 408.526 79.5739 400.663 87.437L358.098 130.002L301.148 73.0516L343.713 30.4869C383.028 -8.82896 446.772 -8.82896 486.088 30.4869L571.513 115.912C610.829 155.228 610.829 218.972 571.513 258.287L357.802 471.999L300.852 415.049L514.563 201.337Z" stroke="url(#paint1_radial)" id="path_1"></path>
                            <path d="M243.901 471.999L201.337 514.563C193.474 522.426 180.725 522.426 172.862 514.563L87.437 429.138C79.5739 421.275 79.5739 408.526 87.437 400.663L301.148 186.952L244.198 130.002L30.4869 343.713C-8.82897 383.028 -8.82897 446.772 30.4869 486.088L115.912 571.513C155.228 610.829 218.972 610.829 258.287 571.513L300.852 528.949L243.901 471.999Z" stroke="url(#paint2_radial)" id="path_2"></path>
                        </g>
                        <ellipse cx="295.027" cy="193.118" transform="translate(-295.027 -193.118)" rx="1.07306" ry="1.07433" fill="#945DD6">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M294.685 193.474L268.932 219.258" transform="translate(-294.685 -193.474) rotate(45 294.685 193.474)" stroke="url(#paint3_linear)">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="295.027" cy="193.118" transform="translate(-295.027 -193.118)" rx="1.07306" ry="1.07433" fill="#46737">
                            <animateMotion dur="5s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M294.685 193.474L268.932 219.258" transform="translate(-294.685 -193.474) rotate(45 294.685 193.474)" stroke="url(#paint7_linear)">
                            <animateMotion dur="5s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="476.525" cy="363.313" rx="1.07433" ry="1.07306" transform="translate(-476.525 -363.313) rotate(90 476.525 363.313)" fill="#945DD6">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M476.171 362.952L450.417 337.168" transform="translate(-476.525 -363.313) rotate(-45 476.171 362.952)" stroke="url(#paint4_linear)">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="382.164" cy="155.029" rx="1.07433" ry="1.07306" transform="translate(-382.164 -155.029) rotate(90 382.164 155.029)" fill="#F46737">
                            <animateMotion dur="10s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M381.81 154.669L356.057 128.885" transform="translate(-381.81 -154.669) rotate(-45 381.81 154.669)" stroke="url(#paint5_linear)">
                            <animateMotion dur="10s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="333.324" cy="382.691" rx="1.07306" ry="1.07433" transform="translate(-333.324 -382.691) rotate(-180 333.324 382.691)" fill="#F46737">
                            <animateMotion dur="5s" begin="0" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_1"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M333.667 382.335L359.42 356.551" transform="scale(-1 1) translate(-333.667 -382.335) rotate(45 333.667 382.335)" stroke="url(#paint6_linear)">
                            <animateMotion dur="5s" begin="0" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_1"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="165.524" cy="93.9596" rx="1.07306" ry="1.07433" transform="translate(-165.524 -93.9596)" fill="#F46737">
                            <animateMotion dur="10s" begin="3" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M165.182 94.3159L139.429 120.1" transform="translate(-165.182 -94.3159) rotate(45 165.182 94.3159)" stroke="url(#paint7_linear)">
                            <animateMotion dur="10s" begin="3" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="476.525" cy="363.313" rx="1.07433" ry="1.07306" transform="translate(-476.525 -363.313) rotate(90 476.525 363.313)" fill="#13ADC7">
                            <animateMotion dur="12s" begin="4" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M476.171 362.952L450.417 337.168" transform="translate(-476.525 -363.313) rotate(-45 476.171 362.952)" stroke="url(#paint11_linear)">
                            <animateMotion dur="12s" begin="4" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <defs>
                            <radialGradient id="paint0_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(301 301) rotate(90) scale(300)">
                                <stop offset="0.333333" stop-color="#FBFBFB"></stop>
                                <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                            </radialGradient>
                            <radialGradient id="paint1_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(301 301) rotate(90) scale(300)">
                                <stop offset="0.333333" stop-color="#FBFBFB"></stop>
                                <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                            </radialGradient>
                            <radialGradient id="paint2_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(301 301) rotate(90) scale(300)">
                                <stop offset="0.333333" stop-color="#FBFBFB"></stop>
                                <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                            </radialGradient>
                            <linearGradient id="paint3_linear" x1="295.043" y1="193.116" x2="269.975" y2="218.154" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#945DD6"></stop>
                                <stop offset="1" stop-color="#945DD6" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint4_linear" x1="476.529" y1="363.31" x2="451.461" y2="338.272" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#945DD6"></stop>
                                <stop offset="1" stop-color="#945DD6" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint5_linear" x1="382.168" y1="155.027" x2="357.1" y2="129.989" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F46737"></stop>
                                <stop offset="1" stop-color="#F46737" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint6_linear" x1="333.309" y1="382.693" x2="358.376" y2="357.655" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F46737"></stop>
                                <stop offset="1" stop-color="#F46737" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint7_linear" x1="165.54" y1="93.9578" x2="140.472" y2="118.996" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F46737"></stop>
                                <stop offset="1" stop-color="#F46737" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint8_linear" x1="414.367" y1="301.156" x2="439.435" y2="276.118" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#13ADC7"></stop>
                                <stop offset="1" stop-color="#13ADC7" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint9_linear" x1="515.943" y1="288.238" x2="541.339" y2="291.454" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#13ADC7"></stop>
                                <stop offset="1" stop-color="#13ADC7" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint10_linear" x1="117.001" y1="230.619" x2="117.36" y2="258.193" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#945DD6"></stop>
                                <stop offset="1" stop-color="#945DD6" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint11_linear" x1="476.529" y1="363.31" x2="451.461" y2="338.272" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#13ADC7"></stop>
                                <stop offset="1" stop-color="#13ADC7" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>

                    <div class="exp__icon php_icon">
                        <i class='bx bxl-php php'></i>
                    </div>

                    <div class="exp__icon javascript_icon">
                        <i class='bx bxl-nodejs javascript'></i>
                    </div>

                    <!-- <div class="exp__icon wordpress_icon">
                    <i class='bx bxl-wordpress wordpress'></i>
                </div> -->

                    <div class="exp__icon plug_icon">
                        <i class='bx bx-plug plug'></i>
                    </div>

                </div>

            </div>


            <div class="header__footer">
                <div class="header__footer_container">
                    <div class="header__experience">
                        <h1><span id="experience">4</span>+</h1>
                        <p>Years <br> Experience</p>
                    </div>
                    <div class="header__project">
                        <h1><span id="projects">380</span>+</h1>
                        <p>Project Compleated<br> at <b><span id="country">26</span>+</b>
                            Countries</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- introduce section -->
    <section class="introduce" id="skills">
        <div class="skill__container">
            <div class="skill__header">
                <h1 class="sikll__title">Skills</h1>
                <div class="skill__border"></div>
            </div>

            <div class="skill__grid">
                <div class="skill__names">
                    <h1 class="sill__name_title">I have experience in </h1>
                    <div class="my__skills">
                        <ul class="my__skills_list">
                            <li class="my__skills_item">Html5, Css3, Scss</li>
                            <li class="my__skills_item">Bootstrap, Tailwindcss</li>
                            <li class="my__skills_item">Javascript, jQuery, AJAX</li>
                            <li class="my__skills_item">PHP,PHP[OOP], REST API, LARAVEL</li>
                            <li class="my__skills_item">MYSQL, JSON DB</li>
                            <li class="my__skills_item">PSD to Html5, PSD to WordPress/WooCommerce</li>
                            <li class="my__skills_item">WordPress ( Theme Development, Plugin Development) </li>
                        </ul>
                    </div>
                </div>
                <div class="skill__perc">
                    <div class="sill__lists">

                        <div class="skill__item">
                            <h6 class="skillbar__title"><i class='bx bxl-html5'></i></h6>
                            <div class="skillbar" data-percent="95%">
                                <div class="skillbar-bar html5">
                                </div>
                            </div>
                            <h6 class="skillbar__percent"><span class="count">95</span>%</h6>
                        </div>
                        <div class="skill__item">
                            <h6 class="skillbar__title"><i class='bx bxl-nodejs'></i></h6>
                            <div class="skillbar" data-percent="70%">
                                <div class="skillbar-bar js">
                                </div>
                            </div>
                            <h6 class="skillbar__percent"><span class="count">70</span>%</h6>
                        </div>
                        <div class="skill__item">
                            <h6 class="skillbar__title"><i class='bx bxl-php'></i></h6>
                            <div class="skillbar" data-percent="85%">
                                <div class="skillbar-bar php">
                                </div>
                            </div>
                            <h6 class="skillbar__percent"><span class="count">85</span>%</h6>
                        </div>
                        <div class="skill__item">
                            <h6 class="skillbar__title"><i class='bx bxl-wordpress'></i></h6>
                            <div class="skillbar" data-percent="90%">
                                <div class="skillbar-bar wordpress">
                                </div>
                            </div>
                            <h6 class="skillbar__percent "><span class="count">90</span>%</h6>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        <div class="border"></div>
        <div class="introduce__container">
            <div class="introduce__skills">
                <div class="skills__list">
                    <div class="skills__item">
                        <h1 class="skills__title">Plugin Development</h1>
                        <p class="skills__subtitle">I will develop custom WordPress plugin with custom functionality for
                            you.</p>
                        <span class="skills__icon"><i class='bx bxs-plug'></i></span>
                    </div>
                    <div class="skills__item">
                        <h1 class="skills__title">Template Development</h1>
                        <p class="skills__subtitle">I'll convert your dream to custom WordPress and WooCommerce
                            templates. </p>
                        <span class="skills__icon"><i class='bx bxl-visual-studio'></i></span>
                    </div>
                    <div class="skills__item">
                        <h1 class="skills__title">Bugs Fix</h1>
                        <p class="skills__subtitle">I'll fix bugs and add custom functionality on your WordPress
                            website.</p>
                        <span class="skills__icon"><i class='bx bx-bug-alt'></i></span>
                    </div>
                </div>
            </div>
            <div class="introduce__myself">
                <h3 class="introduce__title">Introduce</h3>
                <h1 class="introduce__about">Hello!, I'm Mohammad Ibrahim</h1>

                <p class="intorduce__subtitle">Every great design begin with an even better sotry.</p>
                <p class="intorduce__content">Since beginning my journey as a web developer nearly 4 years ago, I've
                    done remote work for agencies, consulted for startups, and collaborated with talented people to
                    create digital products for both business and customer use. I'm quietly confident, naturally
                    curious, and perpetually working on improving my chops one problem at a time.</p>


                <div class="introduce__working">
                    <h3 class="introduce__work">Working On</h3>

                    <picture>
                        <source srcset="img/logo-fiverr-grey.png.webp" type="image/webp">
                        <img width="77" height="70" src="https://awesomecoder.dev/img/logo-fiverr-grey.png" alt="" loading="lazy">
                    </picture>
                    <picture>
                        <source srcset="img/logo-upwork-grey.png.webp" type="image/webp">
                        <img width="89" height="70" src="https://awesomecoder.dev/img/logo-upwork-grey.png" alt="" loading="lazy">
                    </picture>
                </div>
            </div>
        </div>

    </section>

    <!-- testimonial section -->
    <section class="testmonials" id="testmonials">
        <div class="testmonials__container ">

            <div class="testonials__header">
                <h1 class="testmonials__title">Testmonials</h1>
                <h3 class="testmonials__subtitle">What's client say about me?</h3>
            </div>

            <div class="testmonials__slider">
                <div class="testmonials__list swiper-wrapper">
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>This plugin didn't exist and he made it happen. / Does amazing work. / Went above and
                                beyond.</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/harrystymiest.jpg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">harrystymiest</h1>
                                    <h1 class="testmonials__country">United States</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>Super experience again Work Perfectly fast and good explain Thanks for have find my last
                                issue The PHP have not secret for him stuning service Thanks.</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">addyvey</h1>
                                    <h1 class="testmonials__country">United States</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>Md Ibrahim has done a great job, very responsive and quick to get the job done. Perfect service and would recommend him to anyone and
                                will use again.</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">adammartelletti</h1>
                                    <h1 class="testmonials__country">Australia</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>Excellent, would highly recommend and will definitely use him again. Very polite, helpful
                                and excellent at what he does. Thank you.</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">dave_a434</h1>
                                    <h1 class="testmonials__country">United Kingdom</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>Very professional, on time and also he has a very good taste for design. He knows what he
                                is doing and he communicate is very well.
                                Definitely recommend him.</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">visiontour</h1>
                                    <h1 class="testmonials__country">Canada</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>I would like to thank him for his service and corporation :)</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">bakar686</h1>
                                    <h1 class="testmonials__country">Qatar</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>Very good customer service and did a very good job revamping our website! Super happy
                                with it. Would recommend and will use him again for any future jobs!!!</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">soufianamayour</h1>
                                    <h1 class="testmonials__country">Morocco</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>At time delivery with nice touches. Delivered the product as expected. Recommended.</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">ashishsoutiyal</h1>
                                    <h1 class="testmonials__country">India</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>
                    <div class="testmonials__slider_item swiper-slide">
                        <div class="testmonials__slider_review">
                            <span>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                            </span>
                            <span class="testmonials__rating">5.0 Rating </span>
                        </div>

                        <div class="testmonials__slider_content">
                            <p>Professional plugin Developer, I am really happy with the delivery. Thank you.</p>
                        </div>

                        <a target="_blank" href="https://www.fiverr.com/mkholilulla/">
                            <div class="testmonials__profile">
                                <img src="https://awesomecoder.dev/img/default.svg" alt="Image">
                                <div class="profile__contents">
                                    <h1 class="testmonials__name">ghazanfar_786</h1>
                                    <h1 class="testmonials__country">Pakistan</h1>
                                    <div class="testmonials__border"></div>

                                </div>

                            </div>
                        </a>


                        <div class="testmonials__quote">
                            <i class='bx bxs-quote-right'></i>
                        </div>
                    </div>

                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>

    <!-- about section -->
    <section class="about" id="about">
        <div class="about__container">
            <div class="about__header">
                <h1 class="about__title">About Me</h1>
                <div class="about__border"></div>
            </div>
            <div class="about__details">
                <div class="about__contents">
                    <h1 class="about__details_title">Hello!, I'm Mohammad Ibrahim</h1>
                    <h1 class="about__details_typed">I'm <span id="awesomecoder"></span></h1>
                    <p class="about__details_content"> If you are looking for someone that will make your visions become
                        reality, then look no further. With more than 4+ years of experience working as a developer and
                        working with many clients locally where I live. I have now joined Fiverr to meet new
                        people/companies that might need my service. Contact me and let's talk about what it is.</p>

                    <h1 class="about__seller">I'm Level Two Seller on Fiverr</h1>
                    <a class="about__button" target="_blank" href="https://www.fiverr.com/mkholilulla/">View
                        Profile</a>

                </div>
                <div class="about__profile">
                    <img src="https://awesomecoder.dev/img/profile.jpg" alt="">
                </div>


            </div>

        </div>
    </section>

    <!-- contact section -->
    <section class="contact" id="contact">
        <div class="contact__container">

            <div class="content__header">
                <h1 class="content__title">Contact Me</h1>
                <div class="content__border"></div>
            </div>

            <div class="content__manager">
                <div class="contact__me">
                    <h1 class="contact__title">Contact Information</h1>
                    <h1 class="contact__subtitle">Contact me and I will try to reply to you, within 24 hours.</h1>

                    <div class="contacts">
                        <div class="conact__list">
                            <a target="_blank" href="mailto:awesomecoder.dev@gmail.com" class="contact__item">
                                <i class='bx bx-mail-send'></i><span>awesomecoder.dev@gmail.com</span>
                            </a>
                            <a target="_blank" href="https://api.whatsapp.com/send?phone=8801720115642" class="contact__item">
                                <i class='bx bxl-whatsapp'></i><span>+8801720115642</span>
                            </a>
                            <a target="_blank" href="https://join.skype.com/invite/Y7yD2r4NtWB5" class="contact__item">
                                <i class='bx bxl-skype'></i><span>live:help.md.ibrahim</span>
                            </a>
                        </div>
                    </div>

                    <svg class="contact__svg" viewBox="0 0 602 602" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g opacity="0.15">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M201.337 87.437C193.474 79.5738 180.725 79.5738 172.862 87.437L87.437 172.862C79.5739 180.725 79.5739 193.474 87.437 201.337L400.663 514.563C408.526 522.426 421.275 522.426 429.138 514.563L514.563 429.138C522.426 421.275 522.426 408.526 514.563 400.663L201.337 87.437ZM30.4869 115.912C-8.82897 155.228 -8.82897 218.972 30.4869 258.287L343.713 571.513C383.028 610.829 446.772 610.829 486.088 571.513L571.513 486.088C610.829 446.772 610.829 383.028 571.513 343.713L258.287 30.4869C218.972 -8.82896 155.228 -8.82896 115.912 30.4869L30.4869 115.912Z" stroke="url(#paint0_radial)" id="path_0"></path>
                            <path d="M514.563 201.337C522.426 193.474 522.426 180.725 514.563 172.862L429.138 87.437C421.275 79.5738 408.526 79.5739 400.663 87.437L358.098 130.002L301.148 73.0516L343.713 30.4869C383.028 -8.82896 446.772 -8.82896 486.088 30.4869L571.513 115.912C610.829 155.228 610.829 218.972 571.513 258.287L357.802 471.999L300.852 415.049L514.563 201.337Z" stroke="url(#paint1_radial)" id="path_1"></path>
                            <path d="M243.901 471.999L201.337 514.563C193.474 522.426 180.725 522.426 172.862 514.563L87.437 429.138C79.5739 421.275 79.5739 408.526 87.437 400.663L301.148 186.952L244.198 130.002L30.4869 343.713C-8.82897 383.028 -8.82897 446.772 30.4869 486.088L115.912 571.513C155.228 610.829 218.972 610.829 258.287 571.513L300.852 528.949L243.901 471.999Z" stroke="url(#paint2_radial)" id="path_2"></path>
                        </g>
                        <ellipse cx="295.027" cy="193.118" transform="translate(-295.027 -193.118)" rx="1.07306" ry="1.07433" fill="#945DD6">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M294.685 193.474L268.932 219.258" transform="translate(-294.685 -193.474) rotate(45 294.685 193.474)" stroke="url(#paint3_linear)">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="295.027" cy="193.118" transform="translate(-295.027 -193.118)" rx="1.07306" ry="1.07433" fill="#46737">
                            <animateMotion dur="5s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M294.685 193.474L268.932 219.258" transform="translate(-294.685 -193.474) rotate(45 294.685 193.474)" stroke="url(#paint7_linear)">
                            <animateMotion dur="5s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_2"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="476.525" cy="363.313" rx="1.07433" ry="1.07306" transform="translate(-476.525 -363.313) rotate(90 476.525 363.313)" fill="#945DD6">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M476.171 362.952L450.417 337.168" transform="translate(-476.525 -363.313) rotate(-45 476.171 362.952)" stroke="url(#paint4_linear)">
                            <animateMotion dur="10s" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="382.164" cy="155.029" rx="1.07433" ry="1.07306" transform="translate(-382.164 -155.029) rotate(90 382.164 155.029)" fill="#F46737">
                            <animateMotion dur="10s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M381.81 154.669L356.057 128.885" transform="translate(-381.81 -154.669) rotate(-45 381.81 154.669)" stroke="url(#paint5_linear)">
                            <animateMotion dur="10s" begin="1" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="333.324" cy="382.691" rx="1.07306" ry="1.07433" transform="translate(-333.324 -382.691) rotate(-180 333.324 382.691)" fill="#F46737">
                            <animateMotion dur="5s" begin="0" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_1"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M333.667 382.335L359.42 356.551" transform="scale(-1 1) translate(-333.667 -382.335) rotate(45 333.667 382.335)" stroke="url(#paint6_linear)">
                            <animateMotion dur="5s" begin="0" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_1"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="165.524" cy="93.9596" rx="1.07306" ry="1.07433" transform="translate(-165.524 -93.9596)" fill="#F46737">
                            <animateMotion dur="10s" begin="3" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M165.182 94.3159L139.429 120.1" transform="translate(-165.182 -94.3159) rotate(45 165.182 94.3159)" stroke="url(#paint7_linear)">
                            <animateMotion dur="10s" begin="3" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <ellipse cx="476.525" cy="363.313" rx="1.07433" ry="1.07306" transform="translate(-476.525 -363.313) rotate(90 476.525 363.313)" fill="#13ADC7">
                            <animateMotion dur="12s" begin="4" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </ellipse>
                        <path d="M476.171 362.952L450.417 337.168" transform="translate(-476.525 -363.313) rotate(-45 476.171 362.952)" stroke="url(#paint11_linear)">
                            <animateMotion dur="12s" begin="4" repeatCount="indefinite" rotate="auto">
                                <mpath xlink:href="#path_0"></mpath>
                            </animateMotion>
                        </path>
                        <defs>
                            <radialGradient id="paint0_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(301 301) rotate(90) scale(300)">
                                <stop offset="0.333333" stop-color="#FBFBFB"></stop>
                                <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                            </radialGradient>
                            <radialGradient id="paint1_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(301 301) rotate(90) scale(300)">
                                <stop offset="0.333333" stop-color="#FBFBFB"></stop>
                                <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                            </radialGradient>
                            <radialGradient id="paint2_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(301 301) rotate(90) scale(300)">
                                <stop offset="0.333333" stop-color="#FBFBFB"></stop>
                                <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                            </radialGradient>
                            <linearGradient id="paint3_linear" x1="295.043" y1="193.116" x2="269.975" y2="218.154" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#945DD6"></stop>
                                <stop offset="1" stop-color="#945DD6" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint4_linear" x1="476.529" y1="363.31" x2="451.461" y2="338.272" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#945DD6"></stop>
                                <stop offset="1" stop-color="#945DD6" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint5_linear" x1="382.168" y1="155.027" x2="357.1" y2="129.989" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F46737"></stop>
                                <stop offset="1" stop-color="#F46737" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint6_linear" x1="333.309" y1="382.693" x2="358.376" y2="357.655" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F46737"></stop>
                                <stop offset="1" stop-color="#F46737" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint7_linear" x1="165.54" y1="93.9578" x2="140.472" y2="118.996" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F46737"></stop>
                                <stop offset="1" stop-color="#F46737" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint8_linear" x1="414.367" y1="301.156" x2="439.435" y2="276.118" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#13ADC7"></stop>
                                <stop offset="1" stop-color="#13ADC7" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint9_linear" x1="515.943" y1="288.238" x2="541.339" y2="291.454" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#13ADC7"></stop>
                                <stop offset="1" stop-color="#13ADC7" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint10_linear" x1="117.001" y1="230.619" x2="117.36" y2="258.193" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#945DD6"></stop>
                                <stop offset="1" stop-color="#945DD6" stop-opacity="0"></stop>
                            </linearGradient>
                            <linearGradient id="paint11_linear" x1="476.529" y1="363.31" x2="451.461" y2="338.272" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#13ADC7"></stop>
                                <stop offset="1" stop-color="#13ADC7" stop-opacity="0"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="contact__details">
                    <h1 class="contact__details_title">Hi there !, <br> You can find me through Google.</h1>
                    <h1 class="contact__details_typed">You can search "Create Custom Plugin Fiverr" on Google, You will
                        find me on the first result from almost 800000+ results .</h1>
                    <p class="contact__details_content">
                        Contact me and let's talk <br> about your project :)
                    </p>

                    <a class="contact__button" target="_blank" href="https://www.google.com/search?q=create+custom+plugin+fiverr">Find Me On
                        Google</a>
                </div>


            </div>
        </div>
    </section>

    <!-- footer section -->
    <footer>
        <div class="footer__container">
            <div class="copy__right_text">
                <p>&copy; <a href="https://awesomecoder.dev/">Awesome<span>Coder</span></a> | All Right Reserved
                    2018-2021
                </p>
            </div>
        </div>

    </footer>

    <!-- App.Js -->
    <script src="https://awesomecoder.dev/js/app.js"></script>

</body>

</html>